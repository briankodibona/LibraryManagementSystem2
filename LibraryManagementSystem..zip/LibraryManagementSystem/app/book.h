#ifndef BOOK_H
#define BOOK_H

#include "libraryitem.h"

class Book : public LibraryItem {
public:
    Book() = default;
    Book(QString title, QString author, int id, QString genre)
        : LibraryItem(std::move(title), std::move(author), id),
          m_genre(std::move(genre)) {}

    const QString& genre() const { return m_genre; }
    void setGenre(const QString &g) { m_genre = g; }

    QString typeTag() const override { return "BOOK"; }

    QString displayInfo() const override {
        return QString("[Book] %1 | Genre: %2").arg(LibraryItem::displayInfo(), m_genre);
    }

    QString serialize() const override {
        return QString("BOOK,%1,%2,%3,%4,%5")
            .arg(title(), author())
            .arg(id())
            .arg(isBorrowed() ? 1 : 0)
            .arg(m_genre);
    }
    void deserialize(const QStringList &parts) override {
        // parts: 0:BOOK, 1:title, 2:author, 3:id, 4:borrowed, 5:genre
        setTitle(parts[1]);
        setAuthor(parts[2]);
        setId(parts[3].toInt());
        setBorrowed(parts[4].toInt() != 0);
        m_genre = parts.value(5);
    }
private:
    QString m_genre;
};

#endif // BOOK_H