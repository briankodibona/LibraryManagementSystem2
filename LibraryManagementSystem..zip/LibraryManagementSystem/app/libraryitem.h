#ifndef LIBRARYITEM_H
#define LIBRARYITEM_H

#include <QString>

class LibraryItem {
public:
    LibraryItem() = default;
    LibraryItem(QString title, QString author, int id)
        : m_title(std::move(title)), m_author(std::move(author)), m_id(id) {}

    virtual ~LibraryItem() = default;

    // getters/setters (encapsulation)
    const QString& title() const { return m_title; }
    void setTitle(const QString &t) { m_title = t; }

    const QString& author() const { return m_author; }
    void setAuthor(const QString &a) { m_author = a; }

    int id() const { return m_id; }
    void setId(int id) { m_id = id; }

    bool isBorrowed() const { return m_borrowed; }
    void setBorrowed(bool b) { m_borrowed = b; }

    virtual QString typeTag() const = 0;

    // Polymorphic display
    virtual QString displayInfo() const {
        return QString("%1 by %2 (ID: %3)%4")
            .arg(m_title, m_author)
            .arg(m_id)
            .arg(m_borrowed ? " [BORROWED]" : "");
    }

    // Persistence helpers (CSV-style): TYPE,title,author,id,borrowed,specific...
    virtual QString serialize() const = 0;
    virtual void deserialize(const QStringList &parts) = 0;

protected:
    QString m_title;
    QString m_author;
    int m_id = 0;
    bool m_borrowed = false;
};

#endif // LIBRARYITEM_H