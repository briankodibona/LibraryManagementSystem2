// Intentionally empty; header-only virtual base implementation.
