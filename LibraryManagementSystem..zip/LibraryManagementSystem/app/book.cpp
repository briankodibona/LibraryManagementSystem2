// Intentionally empty; Book methods are inline.
