#ifndef MAGAZINE_H
#define MAGAZINE_H

#include "libraryitem.h"

class Magazine : public LibraryItem {
public:
    Magazine() = default;
    Magazine(QString title, QString author, int id, int issueNumber)
        : LibraryItem(std::move(title), std::move(author), id),
          m_issueNumber(issueNumber) {}

    int issueNumber() const { return m_issueNumber; }
    void setIssueNumber(int n) { m_issueNumber = n; }

    QString typeTag() const override { return "MAG"; }

    QString displayInfo() const override {
        return QString("[Magazine] %1 | Issue #%2")
            .arg(LibraryItem::displayInfo())
            .arg(m_issueNumber);
    }

    QString serialize() const override {
        return QString("MAG,%1,%2,%3,%4,%5")
            .arg(title(), author())
            .arg(id())
            .arg(isBorrowed() ? 1 : 0)
            .arg(m_issueNumber);
    }
    void deserialize(const QStringList &parts) override {
        // parts: 0:MAG, 1:title, 2:author, 3:id, 4:borrowed, 5:issue
        setTitle(parts[1]);
        setAuthor(parts[2]);
        setId(parts[3].toInt());
        setBorrowed(parts[4].toInt() != 0);
        m_issueNumber = parts.value(5).toInt();
    }
private:
    int m_issueNumber = 0;
};

#endif // MAGAZINE_H