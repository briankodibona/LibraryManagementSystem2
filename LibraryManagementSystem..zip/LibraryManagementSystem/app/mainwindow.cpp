#include "mainwindow.h"
#include "book.h"
#include "magazine.h"

#include <QListView>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLineEdit>
#include <QLabel>
#include <QPushButton>
#include <QSpinBox>
#include <QComboBox>
#include <QStandardItem>
#include <QFileDialog>
#include <QDir>
#include <QCoreApplication>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent),
    model_(new QStandardItemModel(this)),
    proxy_(new QSortFilterProxyModel(this))
{
    setupUi();

    // Data path in application dir
    dataPath_ = QDir(QCoreApplication::applicationDirPath()).filePath("library_data.txt");

    loadData();
    refreshModel(items_);

    connect(searchEdit_, &QLineEdit::textChanged, this, &MainWindow::searchTextChanged);
    connect(sortCombo_, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &MainWindow::sortChanged);
}

MainWindow::~MainWindow() {
    saveData();
    qDeleteAll(items_);
}

void MainWindow::setupUi() {
    QWidget *central = new QWidget(this);
    QVBoxLayout *root = new QVBoxLayout(central);

    // Top: inputs
    QHBoxLayout *row1 = new QHBoxLayout();
    titleEdit_ = new QLineEdit(); authorEdit_ = new QLineEdit();
    idSpin_ = new QSpinBox(); idSpin_->setMaximum(1'000'000);
    genreEdit_ = new QLineEdit(); issueSpin_ = new QSpinBox(); issueSpin_->setMaximum(1'000'000);
    row1->addWidget(new QLabel("Title:")); row1->addWidget(titleEdit_);
    row1->addWidget(new QLabel("Author:")); row1->addWidget(authorEdit_);
    row1->addWidget(new QLabel("ID:")); row1->addWidget(idSpin_);
    root->addLayout(row1);

    QHBoxLayout *row2 = new QHBoxLayout();
    row2->addWidget(new QLabel("Genre (Book):")); row2->addWidget(genreEdit_);
    row2->addWidget(new QLabel("Issue# (Magazine):")); row2->addWidget(issueSpin_);
    QPushButton *addBookBtn = new QPushButton("Add Book");
    QPushButton *addMagBtn = new QPushButton("Add Magazine");
    row2->addWidget(addBookBtn);
    row2->addWidget(addMagBtn);
    root->addLayout(row2);

    // Search & sort
    QHBoxLayout *row3 = new QHBoxLayout();
    searchEdit_ = new QLineEdit();
    sortCombo_ = new QComboBox();
    sortCombo_->addItems({"Title A→Z", "Author A→Z", "ID Asc"});
    row3->addWidget(new QLabel("Search:"));
    row3->addWidget(searchEdit_);
    row3->addWidget(new QLabel("Sort by:"));
    row3->addWidget(sortCombo_);
    QPushButton *borrowBtn = new QPushButton("Borrow");
    QPushButton *returnBtn = new QPushButton("Return");
    row3->addWidget(borrowBtn);
    row3->addWidget(returnBtn);
    root->addLayout(row3);

    // List view
    listView_ = new QListView();
    proxy_->setSourceModel(model_);
    proxy_->setFilterCaseSensitivity(Qt::CaseInsensitive);
    listView_->setModel(proxy_);
    root->addWidget(listView_);

    setCentralWidget(central);
    setWindowTitle("Library Management System (Qt)");

    connect(addBookBtn, &QPushButton::clicked, this, &MainWindow::addBook);
    connect(addMagBtn, &QPushButton::clicked, this, &MainWindow::addMagazine);
    connect(borrowBtn, &QPushButton::clicked, this, &MainWindow::borrowSelected);
    connect(returnBtn, &QPushButton::clicked, this, &MainWindow::returnSelected);
}

void MainWindow::refreshModel(const QList<LibraryItem*> &source) {
    model_->clear();
    for (auto *it : source) {
        auto *item = new QStandardItem(it->displayInfo());
        // store pointer in item data (as quintptr for safety). We don't own it.
        item->setData(QVariant::fromValue<qulonglong>(reinterpret_cast<qulonglong>(it)));
        model_->appendRow(item);
    }
}

void MainWindow::addBook() {
    if (titleEdit_->text().isEmpty() || authorEdit_->text().isEmpty()) {
        QMessageBox::warning(this, "Missing data", "Please provide Title and Author.");
        return;
    }
    Book *b = new Book(titleEdit_->text(), authorEdit_->text(), idSpin_->value(), genreEdit_->text());
    items_.append(b);
    refreshModel(items_);
    saveData();
}

void MainWindow::addMagazine() {
    if (titleEdit_->text().isEmpty() || authorEdit_->text().isEmpty()) {
        QMessageBox::warning(this, "Missing data", "Please provide Title and Author.");
        return;
    }
    Magazine *m = new Magazine(titleEdit_->text(), authorEdit_->text(), idSpin_->value(), issueSpin_->value());
    items_.append(m);
    refreshModel(items_);
    saveData();
}

void MainWindow::searchTextChanged(const QString &text) {
    proxy_->setFilterFixedString(text);
}

void MainWindow::sortChanged(int index) {
    using namespace LibraryUtils;
    switch (index) {
        case 0: // title
            LibraryUtils::sort(items_, [](const LibraryItem* a, const LibraryItem* b){
                return a->title().compare(b->title(), Qt::CaseInsensitive) < 0;
            }); break;
        case 1: // author
            LibraryUtils::sort(items_, [](const LibraryItem* a, const LibraryItem* b){
                return a->author().compare(b->author(), Qt::CaseInsensitive) < 0;
            }); break;
        case 2: // id
            LibraryUtils::sort(items_, [](const LibraryItem* a, const LibraryItem* b){
                return a->id() < b->id();
            }); break;
    }
    refreshModel(items_);
}

void MainWindow::borrowSelected() {
    QModelIndex idx = listView_->currentIndex();
    if (!idx.isValid()) return;
    QModelIndex src = proxy_->mapToSource(idx);
    QStandardItem *row = model_->itemFromIndex(src);
    auto ptr = reinterpret_cast<LibraryItem*>(row->data().toULongLong());
    if (ptr) {
        ptr->setBorrowed(true);
        row->setText(ptr->displayInfo());
        saveData();
    }
}

void MainWindow::returnSelected() {
    QModelIndex idx = listView_->currentIndex();
    if (!idx.isValid()) return;
    QModelIndex src = proxy_->mapToSource(idx);
    QStandardItem *row = model_->itemFromIndex(src);
    auto ptr = reinterpret_cast<LibraryItem*>(row->data().toULongLong());
    if (ptr) {
        ptr->setBorrowed(false);
        row->setText(ptr->displayInfo());
        saveData();
    }
}

void MainWindow::saveData() {
    LibraryUtils::saveToFile(dataPath_, items_);
}

void MainWindow::loadData() {
    LibraryUtils::loadFromFile(dataPath_, items_);
    // Demonstrate Storage<T>
    for (auto *it : items_) storage_.add(it);
}