// Intentionally empty; Magazine methods are inline.
