#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QList>
#include <QStandardItemModel>
#include <QSortFilterProxyModel>
#include "../libraryutils/libraryutils.h"

class QLineEdit;
class QPushButton;
class QListView;
class QComboBox;
class QLabel;
class QSpinBox;

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void addBook();
    void addMagazine();
    void searchTextChanged(const QString& text);
    void sortChanged(int index);
    void borrowSelected();
    void returnSelected();
    void saveData();

private:
    void setupUi();
    void refreshModel(const QList<LibraryItem*> &source);
    void loadData();

    QList<LibraryItem*> items_;
    Storage<LibraryItem*> storage_; // Demonstrate template usage
    QStandardItemModel *model_;
    QSortFilterProxyModel *proxy_;
    QListView *listView_;

    // Inputs
    QLineEdit *titleEdit_;
    QLineEdit *authorEdit_;
    QSpinBox *idSpin_;
    QLineEdit *genreEdit_;
    QSpinBox *issueSpin_;

    QLineEdit *searchEdit_;
    QComboBox *sortCombo_;

    QString dataPath_;
};

#endif // MAINWINDOW_H