#include "libraryutils.h"
#include "../app/libraryitem.h"
#include "../app/book.h"
#include "../app/magazine.h"
#include <QRegularExpression>

namespace LibraryUtils {

bool saveToFile(const QString &path, const QList<LibraryItem*> &items) {
    QFile f(path);
    if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) return false;
    QTextStream out(&f);
    for (auto *it : items) {
        out << it->serialize() << "\n";
    }
    return true;
}

int loadFromFile(const QString &path, QList<LibraryItem*> &items) {
    QFile f(path);
    if (!f.exists()) return 0;
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) return 0;
    QTextStream in(&f);
    int count = 0;
    while (!in.atEnd()) {
        const QString line = in.readLine().trimmed();
        if (line.isEmpty()) continue;
        const QStringList parts = line.split(',');
        if (parts.size() < 6) continue;
        const QString type = parts[0];
        if (type == "BOOK") {
            Book *b = new Book();
            b->deserialize(parts);
            items.append(b);
            ++count;
        } else if (type == "MAG") {
            Magazine *m = new Magazine();
            m->deserialize(parts);
            items.append(m);
            ++count;
        }
    }
    return count;
}

void sort(QList<LibraryItem*> &items, std::function<bool(const LibraryItem*, const LibraryItem*)> less) {
    std::sort(items.begin(), items.end(), less);
}

QList<LibraryItem*> filterByText(const QList<LibraryItem*> &items, const QString &text) {
    QList<LibraryItem*> out;
    const QString needle = text.trimmed();
    for (auto *it : items) {
        if (it->title().contains(needle, Qt::CaseInsensitive) ||
            it->author().contains(needle, Qt::CaseInsensitive)) {
            out.append(it);
        }
    }
    return out;
}

} // namespace LibraryUtils