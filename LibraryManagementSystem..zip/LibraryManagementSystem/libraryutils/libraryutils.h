#ifndef LIBRARYUTILS_H
#define LIBRARYUTILS_H

#include <QObject>
#include <QList>
#include <QString>
#include <QFile>
#include <QTextStream>
#include <functional>

class LibraryItem; // forward declaration

namespace LibraryUtils {

// Save items to a simple CSV-like file
bool saveToFile(const QString &path, const QList<LibraryItem*> &items);

// Load items from file. The factory creates derived objects based on a type tag in file.
// Returns number of items loaded.
int loadFromFile(const QString &path, QList<LibraryItem*> &items);

// Generic sort utility: provide a comparator
void sort(QList<LibraryItem*> &items, std::function<bool(const LibraryItem*, const LibraryItem*)> less);

// Generic filter utility: returns a new filtered list matching a predicate (case-insensitive contains on title/author provided separately)
QList<LibraryItem*> filterByText(const QList<LibraryItem*> &items, const QString &text);

} // namespace LibraryUtils

// ====== Template container ======
template <typename T>
class Storage {
public:
    bool add(const T &value) {
        data_.append(value);
        return true;
    }
    bool remove(const T &value) {
        return data_.removeOne(value);
    }
    // find by predicate, returns first match or default-constructed
    T find(std::function<bool(const T&)> pred) const {
        for (const auto &v : data_) if (pred(v)) return v;
        return T();
    }
    const QList<T>& data() const { return data_; }
    QList<T>& data() { return data_; }
private:
    QList<T> data_;
};

#endif // LIBRARYUTILS_H